========================================================================
       Windows CE APPLICATION : RDP_autoLogin
========================================================================


AppWizard has created this RDP_autoLogin application for you.  

This file contains a summary of what you will find in each of the files that
make up your RDP_autoLogin application.

RDP_autoLogin.cpp
    This is the main application source file.

RDP_autoLogin.h
    This is the main header file for the application.  It includes other
    project specific headers (including Resource.h).

RDP_autoLogin.vcp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.vcp) file, but they should export the makefiles locally.
	

/////////////////////////////////////////////////////////////////////////////
AppWizard has created the following resources:

RDP_autoLogin.rc
    This is a listing of all of the Microsoft Windows CE resources that the
    program uses.  This file can be directly edited in Microsoft
	eMbedded Visual C++.

RDP_autoLogin.ico
    This is an icon file, which is used as the application's icon (32x32).
    This icon is included by the main resource file RDP_autoLogin.rc.


/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named RDP_autoLogin.pch and a precompiled types file named StdAfx.obj.

Resource.h
    This is the standard header file, which defines new resource IDs.
    Microsoft eMbedded Visual C++ reads and updates this file.

Newres.h
    This header file is used to replace the ..\mfc\include\afxres.h.


/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.


/////////////////////////////////////////////////////////////////////////////
