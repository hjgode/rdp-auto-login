//getUUID.h

BOOL GetUUID (TCHAR*) ;
