//tscDialog.h

int startTSC();

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam);

